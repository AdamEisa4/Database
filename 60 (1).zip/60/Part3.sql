DROP table IF EXISTS dbo.
RESULTS_ATTRACTIONS
DROP table IF EXISTS dbo.
RESULTS_PACKAGES
DROP TABLE IF EXISTS dbo.
SEARCHES
DROP table IF EXISTS dbo.
DEALS
DROP TABLE IF EXISTS dbo.
PACKAGES
DROP TABLE IF EXISTS dbo.
TICKETS
DROP TABLE IF EXISTS dbo.
ATTRACTIONS
DROP TABLE IF EXISTS dbo.
canceled_orders
DROP TABLE  IF EXISTS dbo.
ORDERS
DROP TABLE IF EXISTS dbo.
tickets_history
DROP TABLE  IF EXISTS dbo.
CREDITCARDS 
DROP TABLE IF EXISTS dbo.
LOCATIONS







--------------TABLES
CREATE TABLE PACKAGES (
    packageName varchar(100) primary key not null  ,
	price money,
    discount Decimal(32),
	--constraint ck_discount check ( discount>=0 and discount<=1) ,
	constraint ck_price1 check ( price > 0 ) 

)


CREATE TABLE CREDITCARDS (
    cardNumber varchar(12)  not null  ,
    cardValidityMonth tinyint not null ,
	cardValidityYear int  not null,
	cardCVV varchar(4),
	primary key (cardNumber,cardValidityMonth,cardValidityYear),
	constraint ck_cardValidityMonth check (cardValidityMonth>= 1 and cardValidityMonth<=12)  ,

)

CREATE TABLE ORDERS (
    orderNumber varchar(20) not null  ,
	orderDT DATE,
    email varchar(30),
	[address-Street] varchar(20) ,
	[address-Number] int ,
	[address-City] varchar(10) ,
	[address-Country] varchar(10),
	[address-PostalCode] varchar(20) ,
	cardNumber varchar(12)   ,
	cardValidityMonth tinyint  ,
	cardValidityYear int ,
	primary key (orderNumber),
	FOREIGN KEY (cardNumber,cardValidityMonth,cardValidityYear ) REFERENCES CREDITCARDS(cardNumber,cardValidityMonth,cardValidityYear),
	constraint ck_email check (email like '%@%.%' ),
	)


CREATE TABLE ATTRACTIONS (
    AttractionName varchar(50) not null  ,
    Location_  varchar(50) not null ,
	Details varchar(100) ,
	price money,
	primary key ( AttractionName, Location_),
	constraint ck_price2 check ( price > 0 ) 
)


create table TICKETS (
	AttractionName varchar(50) not null ,
	Location_ varchar(50) not null ,
	IDTicket varchar(20)  not null ,
	DT DATE ,
	ticketType varchar(15) ,
	orderNumber varchar(20) not null ,
	primary key (IDTicket),

	foreign key (orderNumber) references ORDERS(orderNumber) ,
	foreign key (AttractionName,Location_) references ATTRACTIONS(AttractionName, Location_) ,


)

create table SEARCHES (
	SearchIP varchar(15)not null ,
	DTSearch smallDateTime not null ,
	SearchByName varchar(50) ,
	orderNumber varchar(20), 
	primary key (SearchIP,DTSearch) , 
	foreign key (orderNumber) references ORDERS(orderNumber)
)


CREATE TABLE DEALS (
    PackageName varchar(100) not null ,
	AttractionName varchar(50) not null  ,
  Location_  varchar(50) not null ,

	primary key (PackageName, AttractionName, Location_) ,
	foreign key (PackageName) references PACKAGES(PackageName) ,
	foreign key (AttractionName,Location_) references ATTRACTIONS(AttractionName,Location_)

)


create table RESULTS_ATTRACTIONS(
	SearchIP varchar(15)not null ,
	DTSearch smallDateTime not null ,
	AttractionName varchar(50) not null ,
	Location_ varchar(50) not null ,

	PRIMARY KEY (SearchIP,DTSearch, AttractionName,Location_) ,
	foreign key (AttractionName,Location_) references ATTRACTIONS(AttractionName,Location_) ,
	foreign key (SearchIP,DTSearch) references SEARCHES(SearchIP,DTSearch)	,
)


create table RESULTS_PACKAGES(
	SearchIP varchar(15)not null ,
	DTSearch smallDateTime not null ,
	PackageName varchar(100) not null  ,

	PRIMARY KEY (SearchIP,DTSearch,PackageName) ,
	foreign key (PackageName) references PACKAGES(PackageName) ,
	foreign key (SearchIP,DTSearch) references SEARCHES(SearchIP,DTSearch) ,
)
 
CREATE TABLE LOCATIONS(
	Location_ varchar(50) Not null,

	constraint pk_country primary Key (Location_),
)

--------LOOKUP_TABLE
Insert Into LOCATIONS Values 
('London UK'),
('Merritt Island, FL , US'),
('Orlando , FL, US'),
('Paris France'),
('Andorra la Vella, Andorra'),
('Luanda,  Angola'),
('Buenos Aires, Argentina'),
('Canberra, Australia'),
('Nassau, The Bahamas'),
('Manama, Bahrain'),
('Belmopan, Belize'),
('Thimphu, Bhutan'),
('Gitega, Burundi'),
('Phnom Penh, Cambodia'),
('Bogota, Colombia'),
('Moroni, Comoros'),
('Zagreb, Croatia'),
('Havana, Cuba'),
('Nicosia, Cyprus'),
('Copenhagen,Denmark'),
('Djibouti, Djibouti'),
('Dili'),
('Quito,Ecuador'),
('Berlin, Germany'),
('Georgetown, Guyana'),
('Jakarta, Indonesia'),
('Baghdad, Iraq'),
('Riga, Latvia'),
('Maseru, Lesotho')
	alter table  ATTRACTIONS
	ADD CONSTRAINT fk_locations foreign key (Location_) references  LOCATIONS(Location_)

--������  �� ������ ������
    SELECT  O.email, [Date] = CAST (S.DTSearch as varchar), [Total Orders] = COUNT (*)
	FROM CREDITCARDS AS CC JOIN ORDERS AS O ON CC.cardNumber = O.cardNumber
	JOIN SEARCHES AS S ON s.orderNumber= O.orderNumber
	WHERE LEN(CC.cardCVV)= 3 AND S.DTSearch LIKE '%NOV 26 2021%' 
	GROUP BY O.email, S.DTSearch
	HAVING COUNT (*) > 0 
	ORDER BY S.DTSearch

--������ �� ������ �����
	SELECT O.cardNumber, T.DT , T.AttractionName 
	FROM ORDERS AS O JOIN TICKETS AS T ON O.orderNumber = T.orderNumber
		JOIN CREDITCARDS AS CC ON CC.cardNumber = O.cardNumber
		WHERE T.DT LIKE '%2022%' AND T.AttractionName LIKE '%Universal%'
	ORDER BY T.DT ASC

	------complex query_1   
	select  
		   [percentage of total orders 2022] =cast( [number of orders] as float)*100/(select sum([number of orders])
		   from (select [address-Country], [number of orders] = count (o.orderNumber)
					from orders as o join TICKETS as T on o.orderNumber = t.orderNumber
					WHERE T.DT LIKE '%2022%'
					group by [address-Country])  as [orders by country 2022])

	 from (	select [address-Country], [number of orders] = count (o.orderNumber)
			from orders as o join TICKETS as T on o.orderNumber = t.orderNumber
			WHERE T.DT LIKE '%2022%' and [address-Country] = 'japan'
			group by [address-Country])
	as tot_amount 

	---------------- complex query_2  
select order_seassons.seasson,[total orders per seasson]=count(*),[total sales] = sum(a.price)
from (
		select *,seasson = (case 
							when month(o.orderDT) between 3 and 5 then 'spring'
							when month(o.orderDT) between 6 and 8 then 'summer'
							when month(o.orderDT) between 9 and 11 then 'fall'
							else                                        'winter'  end)
		from orders as o 
		) as order_seassons join TICKETS as t on order_seassons.orderNumber = t.orderNumber join ATTRACTIONS as a on a.AttractionName = t.AttractionName
group by seasson 

	------------ update V
	alter table ATTRACTIONS drop column [Total sales] 
	alter table ATTRACTIONS drop column [Total orders] 
	alter table ATTRACTIONS drop column [stars rank of the year] 

	alter table ATTRACTIONS add [Total orders] int
	alter table ATTRACTIONS add [Total sales] int
	alter table ATTRACTIONS add [star rank] varchar(10) 

	update ATTRACTIONS 
		set [Total orders] =(
			select  COUNT(*)
			from TICKETS as t 
			where ATTRACTIONS.AttractionName = t.AttractionName
			),
			[Total sales] = (price* [Total orders]),
			[star rank] =  CASE		
						When [Total orders] > 20 THEN '5 stars'
						When [Total orders] <5 THEN '3 stars'
						Else '4 stars'
						end																			
-----------------------
--check 

		select *
		from ATTRACTIONS
		order by [Total sales] desc

---------- substraction------------------
select * 
from (
SELECT DISTINCT A.AttractionName,[Customer's Country] = O.[address-Country]
FROM ATTRACTIONS AS A CROSS JOIN ORDERS AS O
EXCEPT
SELECT DISTINCT  T.AttractionName, [Customer's Country] = O.[address-Country]
FROM ORDERS AS O JOIN TICKETS AS T ON O.orderNumber= T.orderNumber
) as [AttractionNotVisited_byCountry]
WHERE  AttractionNotVisited_byCountry.[Customer's Country] = 'china'
----------------------------------------

--view-----------------------
	
	DROP view IF EXISTS dbo.orders_forMarketing
go
create view orders_forMarketing as (
select  orderNumber ,o.orderDT, o.email ,	o.[address-Street],o.[address-Number],o.[address-City],o.[address-Country], o.[address-PostalCode] 
from orders as o)
go
--------------------------function_1   
go
DROP function IF EXISTS dbo.f_num_of_searches_byname
go
create function f_num_of_searches_byname (@NAME_OF_ATTRACTION varchar(20) )
returns int
as begin
	declare @tot int
	select @tot= count(*)
	from SEARCHES as s
	where s.SearchByName=@NAME_OF_ATTRACTION
	return @tot
end
go
---------------------------check
select [Number of searches for attraction] =  dbo.f_num_of_searches_byname ('Disney World')

---------------- function_2  V
drop function search_order_details
go
create function search_order_details (@orderNumber varchar(20))
returns table 
as return 
select *
from TICKETS as t 
where t.orderNumber=@orderNumber
go
--check
select *
from search_order_details('101785681563819')

----------------------------
go

DROP table IF EXISTS dbo.canceled_orders


CREATE TABLE canceled_orders(
    email varchar(30) not null,
	[address-Country] varchar(10),
	[address-City] varchar(10) ,
	[address-Street] varchar(20) ,
	[address-Number] int ,
	[address-PostalCode] varchar(20) ,
	primary key (email),
	constraint ck_emails check (email like '%@%.%' ),
	)
 
 ----------------------- trigger   V
 DROP Trigger IF EXISTS dbo.
	canceling_orders
go
create trigger canceling_orders 
			on ORDERS
			for delete 
as 
	insert into canceled_orders 
	select deleted.email,deleted.[address-Country],deleted.[address-City],deleted.[address-Street],deleted.[address-Number],deleted.[address-PostalCode]
	from deleted
----------------------------------------
 update searches
	set orderNumber = null
	where searches.orderNumber  = '101785681563819'
DELETE FROM TICKETS WHERE orderNumber='101785681563819';
DELETE FROM ORDERS WHERE orderNumber='101785681563819';
----------------------------------------------------------

select*
from canceled_orders


---------------------- procedure V 

DROP table IF EXISTS dbo.UPDATE_Price
go
CREATE PROCEDURE UPDATE_Price (@Location_ varchar(50))
AS 
UPDATE ATTRACTIONS
SET price = CASE WHEN 
price<50
THEN 1.1*price
ELSE 1.05*price
END
FROM ATTRACTIONS AS A JOIN TICKETS AS T ON A.AttractionName=T.AttractionName
WHERE A.Location_=  @Location_ 
-------------------------------
execute UPDATE_Price  'Orlando , FL, US'

SELECT * FROM ATTRACTIONS
------------------------------
--powerbi views --- V

----- customers by countries
go
 DROP view IF EXISTS Customers_by_countries
go

create view Customers_by_countries as 
select [address-Country], [number of orders] = count (o.orderNumber)
	from orders as o join TICKETS as T on o.orderNumber = t.orderNumber
	group by [address-Country]
	go

---------------------ticket_per_seassons

	--DROP VIEW IF EXISTS ticket_per_seassons
	 DROP view IF EXISTS dbo.ticket_per_seassons
go
	CREATE VIEW ticket_per_seassons as
select ticket_seassons.seasson,[total ticket per seasson]=count(*)
from (
		select *,seasson = (case 
							when month(T.DT) between 3 and 5 then 'spring'
							when month(T.DT) between 6 and 8 then 'summer'
							when month(T.DT) between 9 and 11 then 'fall'
							else                                        'winter'  end)
		FROM TICKETS AS T 
		) as ticket_seassons join TICKETS as t on ticket_seassons.orderNumber = t.orderNumber join ATTRACTIONS as a on a.AttractionName = t.AttractionName
group by seasson
go
-----------------------attractions_by_ticket_type
 DROP view IF EXISTS attractions_by_ticket_type
go
create view attractions_by_ticket_type as 
select t.AttractionName, t.ticketType ,visitors= count (*)
	from TICKETS as T
	group by t.AttractionName,t.ticketType
	order by AttractionName
	go

	-------------------------------
	DROP VIEW IF EXISTS attraction_popularity
go
CREATE VIEW attraction_popularity AS	
	select t.AttractionName,[Total orders]=count(*)
	from  TICKETS as t
	group by t.AttractionName
	go
	------------------------------
DROP VIEW IF EXISTS sales_per_attractions
go
	create view sales_per_attractions as 
select a.AttractionName , [total sales] = a.[Total orders]*att.price
	from attraction_popularity as a join ATTRACTIONS as att on a.AttractionName = att.AttractionName
go
-----------------------------	

DROP VIEW IF EXISTS Income_attraction
go
CREATE VIEW Income_attraction AS
select o.orderDT,a.AttractionName,
       price =  sum(a.price) OVER(PARTITION BY ( o.orderNumber)) ,
	   [new price] = 1.1* sum(a.price) OVER(PARTITION BY ( o.orderNumber))
from ATTRACTIONS as a join TICKETS as t on a.AttractionName =t.AttractionName
     join ORDERS as o on o.orderNumber = t.orderNumber
	 go

------------------------��� �������
DROP VIEW IF EXISTS Increase_Reservations
go
CREATE VIEW Increase_Reservations AS
SELECT  T.AttractionName,  [orders Target] = round(Count(O.orderNumber)*1.1,0)
FROM ORDERS AS O JOIN TICKETS AS T ON O.orderNumber=T.orderNumber
GROUP BY T.AttractionName
go

-----------------------Searches_without_ordering 
DROP view IF EXISTS Searches_without_ordering
go
CREATE VIEW Searches_without_ordering as
SELECT S.SearchByName, [total Searches without ordering]=count(S.SearchByName), S.DTSearch
FROM SEARCHES AS S 
WHERE S.orderNumber IS NULL
GROUP BY S.SearchByName, S.DTSearch
go
---------------------------------

--------windows function_1 V
select distinct country = o.[address-Country] ,
[order number] =  o.orderNumber ,
o.email,
sale = s.sale ,
[avg sale per country] = avg(sale) OVER(PARTITION BY (o.[address-Country])),
 rank () over (partition by o.[address-Country] order by sale desc )
					[rank in each country],
							FIRST_VALUE(sale)
over (
partition by o.[address-Country] order by sale desc
		rows between unbounded preceding and unbounded following) [hieghst price of this country]

from sale_per_order as s join ORDERS as o on o.orderNumber = s.orderNumber
order by o.[address-Country] , [rank in each country]

--drop view sale_per_order
go
 DROP view IF EXISTS dbo.sale_per_order
 go
create view sale_per_order as
select orderNumber = o.orderNumber ,sale = sum(a.price)
from ATTRACTIONS as a join TICKETS as t on a.AttractionName =t.AttractionName join ORDERS as o on o.orderNumber = t.orderNumber
group by o.orderNumber
go
---------------------------------------------------windows function_2 V

select country,year, [total year sales],adjacent_years.[previous year sales],[performance change in percentage] =round (
cast([total year sales]-[previous year sales] as float)/[previous year sales] , 2) , LAST_VALUE(country) OVER(
		partition by year
        ORDER BY round (
cast([total year sales]-[previous year sales] as float)/[previous year sales] , 2)
         RANGE BETWEEN 
            UNBOUNDED PRECEDING  AND 
            UNBOUNDED FOLLOWING
    ) [country with the weakest performance of the year]
from (
select country,year, [total year sales],LAG([total year sales],1) OVER (
			PARTITION BY country
			ORDER BY year
		) [previous year sales]
from sales_per_years
) as adjacent_years
where year > '2020'
order by country ,year

--drop view sales_per_years
go
 DROP view IF EXISTS dbo.sales_per_years
 go
create view sales_per_years as
select  year = year(o.orderDT),country=[address-Country], [total year sales] = sum(sale)
from orders as o join sale_per_order as s on s.orderNumber=o.orderNumber
group by year(o.orderDT) , [address-Country]
go

----------------------------------------------------------------------------------tools combination
--drop table tickets_history

create table tickets_history  (
	AttractionName varchar(50) not null ,
	Location_ varchar(50) not null ,
	IDTicket varchar(20)  not null ,
	DT DATE ,
	ticketType varchar(15) ,
	orderNumber varchar(20) not null ,
	email varchar(30),
	primary key (IDTicket),

	foreign key (orderNumber) references ORDERS(orderNumber) ,
	foreign key (AttractionName,Location_) references ATTRACTIONS(AttractionName, Location_) )
--------------------------
--drop function get_email_for_customer_reviews
go
create function get_email_for_customer_reviews (@id_ticket varchar(20))
returns varchar(30)
as begin
	declare @email varchar(30)
	select @email=o.email
	from ORDERS as O join  tickets_history as T on O.orderNumber=T.orderNumber 
	where t.IDTicket=@id_ticket
	return @email
end
go
------------------------------------stored procedure cancel old tickets
go
 DROP PROCEDURE IF EXISTS dbo.update_old_tickets_database
go
CREATE PROCEDURE update_old_tickets_database 
AS 
	delete
	from TICKETS
	where DT <  '12/12/2023' --GETDATE()
go
---------------------------- triger move canceled tickets and update email
--drop trigger old_tickets_for_customer_review
	
create trigger old_tickets_for_customer_review
on tickets
for delete
as 
insert into tickets_history
select * ,null 
from deleted 
update tickets_history
set email =  dbo.get_email_for_customer_reviews(t.IDTicket) 
from tickets_history as t
where t.email is null

----------------------checks

execute update_old_tickets_database

select *
from tickets_history
go

------------------------------with function

---------- block----------
go
with 
Search_classification as (
select type_of_product.name,
type_of_product.type,
s.SearchIP,	
[leads to order]= (case  when s.orderNumber is null then 'no' else 'yes' end ),	
type_of_product.price	

from (
select [name]= a.AttractionName,type= 'attration' ,a.price
from ATTRACTIONS as a 
union
select [name]= p.packageName,type='package',p.price
	from PACKAGES as p)as type_of_product join SEARCHES as s on s.SearchByName=type_of_product.name
),
Search_popularity as (
select distinct sc.name ,
[numbers of searches]= count(*)  over ( partition by sc.name) ,
[percentage of searches from total searches] = round (cast( count(*)  over ( partition by sc.name) as float)/ (select count(*) 
																												from searches),3)
from Search_classification as sc
),
revenue_By_name as (select distinct sc.name, [revenue]=sum(sc.price) over(partition by sc.name)
from Search_classification as sc
where sc.[leads to order] = 'yes'
),
Evaluation as ( 
select distinct sc.name,
	sc.type,
	sc.price,
	[numbers of searches],
	sp.[percentage of searches from total searches],
	[total revenue]=rev.revenue,
	[rank by revenue] = case when
									rev.revenue >1500 then 'A'
							WHEN rev.revenue<1500 and rev.revenue>200 then 'C'
							else 'B' end 
from Search_classification as sc join Search_popularity as sp on sc.name=sp.name join revenue_By_name as rev on sp.name=rev.name
)
select *
from Evaluation
